"""from fastapi import FastAPI, Request,BackgroundTasks
import httpx
import html
import re
import json
from ollama import Client
from ticket_router_glpi.learning_scripts.config import System_prompt

app = FastAPI()

# V1 credentials
APP_TOKEN = "PKgHlk9Z8NXNneMeQ6WKMK3BbY9TZ7aK0k3bLPmx"
USER_TOKEN = "6eZwVjdYT5rs3hFr1ZZbhhmimFfJRkBpAp3R68Jn"
GLPI_BASE = "http://localhost:8080/apirest.php"

def clean(body: dict):
    body["item"]["content"] = re.sub(r'<[^>]+>', '', html.unescape(body["item"]["content"]))
    return body

assistant = Client(host="http://localhost:11434")

def router(prompt):
    print("pre llm loading")
    response = assistant.chat(
        model="qwen3.5:9b",
        think=False,
        messages=[{"role": "system", "content": System_prompt}, {"role": "user", "content": prompt}]
    )
    print("llm loaded")
    print(response.message.content)
    return response.message.content

async def get_session_token():
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"{GLPI_BASE}/initSession",
            headers={
                "Authorization": f"user_token {USER_TOKEN}",
                "App-Token": APP_TOKEN
            }
        )
        return response.json()["session_token"]

async def update(ticket_id, session_token, route):
    body = json.loads(route)
    async with httpx.AsyncClient() as client:
        response = await client.patch(
            f"{GLPI_BASE}/Ticket/{ticket_id}",
            headers={
                "Session-Token": session_token,
                "App-Token": APP_TOKEN,
                "Content-Type": "application/json"
            },
            json={"input": body}
        )
        print(response.status_code)
        print(response.json())
@app.post("/glpi")
async def glpi(data: Request, background_tasks: BackgroundTasks):
    body = await data.json()
    background_tasks.add_task(process_ticket, body)
    return {"200": "ok"}

async def process_ticket(body: dict):
    try:
        fix = clean(body)
        ticket_id = fix["item"]["id"]
        prompt = fix["item"]["content"]
        print(prompt)
        route = router(prompt)
        print(route)
        session_token = await get_session_token()
        print(session_token)
        await update(ticket_id, session_token, route)
    except Exception as e:
        print(e)"""